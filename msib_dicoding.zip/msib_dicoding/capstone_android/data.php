<?php

require_once("helper.php");

$query = "SELECT * FROM capstone_android";
$sql = mysqli_query($db_connect, $query);

if ($sql) {

    $result = array();
    while ($row = mysqli_fetch_array($sql)) {
        array_push($result, array(
            "id" => $row["id"],
            "no_weighing" => $row["no_weighing"],
            "date" => $row["date"],
            "time" => $row["time"],
            "driver_name" => $row["driver_name"],
            "no_vehicle" => $row["no_vehicle"],
            "many_bunches" => $row["many_bunches"],
            "bruto" => $row["bruto"],
            "tara" => $row["tara"],
            "neto" => $row["neto"]
        ));
    }

    echo json_encode(array("results" => $result));
}
