package com.dicoding.timsaw

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Data(
    val id: Int,
    val no: Int,
    val time: String,
    val driver: String,
    val platNumber: String,
) : Parcelable
