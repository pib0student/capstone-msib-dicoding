<?php

require_once("helper.php");
parse_str(file_get_contents('php://input'), $_PUT);

$id = $_PUT["id"];
$no_weighing = $_PUT["no_weighing"];
$date = $_PUT["date"];
$time = $_PUT["time"];
$driver_name = $_PUT["driver_name"];
$no_vehicle = $_PUT["no_vehicle"];
$many_bunches = $_PUT["many_bunches"];
$bruto = $_PUT["bruto"];
$tara = $_PUT["tara"];
$neto = $_PUT["neto"];

$query = "UPDATE capstone_android 
    SET no_weighing='$no_weighing', 
        date='$date', time='$time',
        driver_name='$driver_name', no_vehicle='$no_vehicle',
        many_bunches='$many_bunches',
        bruto='$bruto', tara='$tara', neto='$neto'
    WHERE id='$id'";
$sql = mysqli_query($db_connect, $query);

if ($sql) {
    echo json_encode(array("message" => "Updated!"));
} else {
    echo json_encode(array("message" => "Error!"));
}
