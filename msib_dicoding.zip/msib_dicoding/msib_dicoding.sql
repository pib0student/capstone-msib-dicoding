-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 16 Des 2021 pada 11.58
-- Versi server: 10.4.20-MariaDB
-- Versi PHP: 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `msib_dicoding`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `capstone_android`
--

CREATE TABLE `capstone_android` (
  `id` int(11) NOT NULL,
  `no_weighing` int(11) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `driver_name` varchar(50) NOT NULL,
  `no_vehicle` varchar(50) NOT NULL,
  `many_bunches` int(11) NOT NULL,
  `bruto` int(11) NOT NULL,
  `tara` int(11) NOT NULL,
  `neto` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `capstone_android`
--

INSERT INTO `capstone_android` (`id`, `no_weighing`, `date`, `time`, `driver_name`, `no_vehicle`, `many_bunches`, `bruto`, `tara`, `neto`) VALUES
(1, 1, '2021-12-15', '11:44:45', 'Ujang', 'B123XYZ', 123, 231, 312, 132),
(3, 2, '2021-12-15', '11:49:36', 'Sugeng', 'B321XYZ', 345, 312, 541, 431),
(8, 3, '2021-12-16', '17:52:02', 'Gareng', 'KH5454', 532, 421, 12321, 93),
(9, 4, '2021-12-16', '17:54:00', 'Kokong', 'BT8973', 653, 6534, 321, 42352);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `capstone_android`
--
ALTER TABLE `capstone_android`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `capstone_android`
--
ALTER TABLE `capstone_android`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
