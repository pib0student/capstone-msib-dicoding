package com.dicoding.timsaw

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.dicoding.timsaw.databinding.ItemDataBinding

class MainAdapter : RecyclerView.Adapter<MainAdapter.DriverViewHolder>() {

    private var listDriver = ArrayList<Data>()

    fun setDrivers(drivers: List<Data>?){
        if (drivers == null) return
        this.listDriver.clear()
        this.listDriver.addAll(drivers)
    }


    class DriverViewHolder(private val binding: ItemDataBinding): RecyclerView.ViewHolder(binding.root) {

        fun bind(drive: Data){
            with(binding){
                tvNo.text = drive.no.toString()
                tvTime.text = drive.time
                tvDriver.text = drive.driver
                tvPlatNumber.text = drive.platNumber
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DriverViewHolder {
        val itemDataBinding = ItemDataBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return DriverViewHolder(itemDataBinding)
    }

    override fun onBindViewHolder(holder: DriverViewHolder, position: Int) {
        val driver = listDriver[position]
        holder.bind(driver)
    }

    override fun getItemCount(): Int = listDriver.size
}