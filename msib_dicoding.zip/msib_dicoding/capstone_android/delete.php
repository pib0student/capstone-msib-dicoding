<?php

require_once("helper.php");
parse_str(file_get_contents('php://input'), $_DELETE);

$id = $_DELETE["id"];

$query = "DELETE FROM capstone_android WHERE id='$id'";
$sql = mysqli_query($db_connect, $query);

if ($sql) {
    echo json_encode(array("message" => "Deleted!"));
} else {
    echo json_encode(array("message" => "Error!"));
}
