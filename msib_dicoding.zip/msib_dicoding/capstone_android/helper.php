<?php

define('HOST', 'localhost');
define('USERNAME', 'root');
define('PASSWORD', '');
define('DATABASE', 'msib_dicoding');

$db_connect = mysqli_connect(HOST, USERNAME, PASSWORD, DATABASE) or die("Unable connect");

header('Content-Type: aplication/json');
