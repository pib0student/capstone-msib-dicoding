<?php

require_once("helper.php");

$no_weighing = $_POST["no_weighing"];
$date = $_POST["date"];
$time = $_POST["time"];
$driver_name = $_POST["driver_name"];
$no_vehicle = $_POST["no_vehicle"];
$many_bunches = $_POST["many_bunches"];
$bruto = $_POST["bruto"];
$tara = $_POST["tara"];
$neto = $_POST["neto"];

$query = "INSERT INTO capstone_android(
    no_weighing, 
    date, time,
    driver_name, no_vehicle,
    many_bunches,
    bruto, tara, neto
    ) VALUES (
    '$no_weighing', 
    '$date', '$time',
    '$driver_name', '$no_vehicle',
    '$many_bunches',
    '$bruto', '$tara', '$neto')";
$sql = mysqli_query($db_connect, $query);

if ($sql) {
    echo json_encode(array("message" => "Created!"));
} else {
    echo json_encode(array("message" => "Error!"));
}
