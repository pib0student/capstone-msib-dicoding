package com.dicoding.timsaw

object DataDriver {
    fun getDataDriver(): List<Data> {
        val driver = ArrayList<Data>()

        driver.add(
            Data(0,1,"26/Nov/2020 09:00", "Wawan", "B34PH")
        )
        driver.add(
            Data(1,2,"26/Nov/2020 10:00", "Adi", "B6TH4")
        )
        driver.add(
            Data(2,3,"26/Nov/2020 11:00", "Ujang", "BJQ34")
        )
        return driver
    }
}